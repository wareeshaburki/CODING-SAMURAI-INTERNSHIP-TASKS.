import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Server implements Runnable{

    Socket socket;
    public static Vector clients = new Vector();

    public Server(Socket socket) {
        try {
            this.socket = socket;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void run(){
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            clients.add(bufferedWriter);

            while (true) { 
                String messageData = bufferedReader.readLine().trim();
                System.out.println("Message: " + messageData);

                for(int i=0;i<clients.size();i++){
                    try {
                        BufferedWriter bufferedWriter1 = (BufferedWriter) clients.get(i);
                        bufferedWriter1.write(messageData);
                        bufferedWriter1.write("\r\n");
                        bufferedWriter1.flush();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception{
        ServerSocket serverSocket = new ServerSocket(2003);
        while(true){
            Socket socket = serverSocket.accept();
            Server server = new Server(socket);
            Thread thread = new Thread(server);
            thread.start();
        }
    }
}