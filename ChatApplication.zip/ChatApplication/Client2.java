import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Client2 extends JFrame implements ActionListener, Runnable {

    JPanel headerPanel, textPanel, rightPanel,messagePanel, leftPanel;
    JButton sendButton;
    JLabel profileLabel, backLabel, videoLabel, phoneLabel, moreLabel, nameLabel, activeStatusLabel;
    JTextField messageTextField;
    Box verticalBox = Box.createVerticalBox();
    BufferedReader bufferedReader;
    BufferedWriter bufferedWriter;
    String name = "Wareesha Burki";

    public Client2() {
        setLayout(null);
        setSize(400, 600);
        setLocation(850, 50);

        getContentPane().setBackground(Color.white);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(29, 161, 242));
        headerPanel.setBounds(0, 0, 400, 60);
        add(headerPanel);
        headerPanel.setLayout(null);

        backLabel = createImageLabel("3.png", 20, 20, 8, 22);
        headerPanel.add(backLabel);

        backLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                System.exit(0);
            }
        });

        profileLabel = createImageLabel("groupImage.png", 40, 40, 35, 10);
        headerPanel.add(profileLabel);

        videoLabel = createImageLabel("video.png", 25, 25, 275, 17);
        headerPanel.add(videoLabel);

        phoneLabel = createImageLabel("phone.png", 30, 25, 317, 19);
        headerPanel.add(phoneLabel);

        moreLabel = createImageLabel("3icon.png", 10, 20, 360, 19);
        headerPanel.add(moreLabel);

        nameLabel = createTextLabel("Singing Mice", 85, 15, 150, 18, Color.white);
        nameLabel.setFont(new Font("SAN_SERIF", Font.BOLD, 14));
        headerPanel.add(nameLabel);

        activeStatusLabel = createTextLabel("Zarmeen, Wareesha, Saad, Mehwish, Gul, Saniya", 85, 38, 160, 10, Color.white);
        activeStatusLabel.setFont(new Font("SAN_SERIF", Font.PLAIN, 10));
        headerPanel.add(activeStatusLabel);

        textPanel = new JPanel();
        textPanel.setBounds(5, 65, 390, 530);
        add(textPanel);
        textPanel.setLayout(null);

        JScrollPane scrollPane = new JScrollPane(verticalBox);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(390, 500));
        textPanel.add(scrollPane, BorderLayout.CENTER);

        messageTextField = new JTextField();
        messageTextField.setBounds(20, 495, 280, 30);
        messageTextField.setFont(new Font("SAN_SERIF", Font.PLAIN, 14));
        textPanel.add(messageTextField);

        sendButton = new JButton("Send");
        sendButton.setBounds(310, 495, 70, 30);
        sendButton.setBackground(new Color(29, 161, 242));
        sendButton.setForeground(Color.white);
        sendButton.setFont(new Font("SAN_SERIF", Font.PLAIN, 14));
        textPanel.add(sendButton);
        sendButton.addActionListener(this);

        try {
            Socket socket = new Socket ("localhost",2003);
            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

        } catch (Exception e) {
            e.printStackTrace();
        }

        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String message = "<html><p>" + name + "</p><p>" + messageTextField.getText() + "</p></html>";
        messagePanel = formatLabel(message);

        textPanel.setLayout(new BorderLayout());

        rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(messagePanel,BorderLayout.LINE_END);

        verticalBox.add(rightPanel);
        verticalBox.add(Box.createVerticalStrut(15));

        textPanel.add(verticalBox,BorderLayout.PAGE_START);

        verticalBox.revalidate();
        verticalBox.repaint();

        try {
            bufferedWriter.write(message);
            bufferedWriter.write("\r\n");
            bufferedWriter.flush();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        messageTextField.setText("");

        repaint();
        invalidate();
        validate();
    }

    private JLabel createImageLabel(String resourceName, int width, int height, int x, int y) {
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource(resourceName));
        Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(img);
        JLabel label = new JLabel(scaledIcon);
        label.setBounds(x, y, width, height);
        return label;
    }

    private JLabel createTextLabel(String text, int x, int y, int width, int height, Color color){
        JLabel label = new JLabel(text);
        label.setBounds(x, y, width, height);
        label.setForeground(color);
        return label;
    }

    public static JPanel formatLabel(String message){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JLabel messageLabel = new JLabel(message);

        messageLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        messageLabel.setBackground(new Color(29, 161, 242));
        messageLabel.setForeground(Color.white);
        messageLabel.setOpaque(true);
        messageLabel.setBorder(new EmptyBorder(7,15,7,38));

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
        JLabel timeLabel = new JLabel();
        timeLabel.setText(simpleDateFormat.format(calendar.getTime()));
        timeLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        panel.add(timeLabel);

        panel.add(messageLabel);
        return panel;
    }

    public void run(){
        try {
            String message;
            while ((message = bufferedReader.readLine()) != null) { 

                if(message.contains(name)){
                    continue;
                }

                JPanel panel = formatLabel(message);

                leftPanel = new JPanel(new BorderLayout());
                leftPanel.add(panel,BorderLayout.LINE_START);

                verticalBox.add(leftPanel);
                verticalBox.add(Box.createVerticalStrut(15));
                textPanel.add(verticalBox,BorderLayout.PAGE_START);

                repaint();
                invalidate();
                validate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Client2 client2 = new Client2();
        Thread thread = new Thread(client2);
        thread.start();
    }
}
