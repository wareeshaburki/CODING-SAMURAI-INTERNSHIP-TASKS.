import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {

    JPanel loginPanel, dashboardPanel, depositPanel, withdrawPanel, checkBalancePanel;
    JLabel backgroundLabel, headingLabel, usernameLabel, passwordLabel, dashboardLabel, depositLabel, withdrawLabel,
            checkBalanceLabel, existingBalanceLabel,
            depositAmountLabel, withdrawAmountLabel;
    JTextField usernameTextField, depositAmountTextField, withdrawAmountTextField;
    JPasswordField passwordField;
    JButton loginButton, depositButton, withdrawButton, checkBalanceButton, backButton,
            depositAmountButton, withdrawAmountButton, backFromDepositButton, backFromWithdrawButton,
            backFromBalanceButton;
    String[] usernames = new String[] { "wareeshaburki", "shaiqashariq", "aleenaahmad" };
    String[] passwords = new String[] { "wb080808", "ss292929", "aa131313" };
    JCheckBox passwordCheck;
    double balance = 1500, amount;

    public Login() {

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Login Panel");

        ImageIcon backgroundImageIcon = new ImageIcon("login.jpeg");
        Image backgroundImage = backgroundImageIcon.getImage().getScaledInstance(
                Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height,
                Image.SCALE_SMOOTH);
        backgroundLabel = new JLabel(new ImageIcon(backgroundImage));
        setContentPane(backgroundLabel);

        loginPanel = new JPanel();
        loginPanel.setBounds(410, 115, 450, 420);
        loginPanel.setBackground(new Color(0, 0, 139));
        backgroundLabel.add(loginPanel);
        loginPanel.setLayout(null);
        loginPanel.setOpaque(true);

        headingLabel = new JLabel("Automated Teller Machine");
        headingLabel.setHorizontalAlignment(JLabel.CENTER);
        headingLabel.setBounds(0, 70, 440, 40);
        headingLabel.setFont(new Font("Sans Serif", Font.BOLD, 30));
        headingLabel.setForeground(Color.white);
        loginPanel.add(headingLabel);

        usernameLabel = new JLabel("Username: ");
        usernameLabel.setBounds(175, 140, 120, 30);
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        usernameLabel.setForeground(Color.white);
        loginPanel.add(usernameLabel);

        usernameTextField = new JTextField();
        usernameTextField.setBounds(125, 180, 200, 30);
        usernameTextField.setFont(new Font("Arial", Font.BOLD, 16));
        usernameTextField.setForeground(Color.black);
        usernameTextField.setBackground(new Color(200, 200, 200));
        usernameTextField.setHorizontalAlignment(JTextField.CENTER);
        loginPanel.add(usernameTextField);

        passwordLabel = new JLabel("Password: ");
        passwordLabel.setBounds(175, 230, 120, 30);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 18));
        passwordLabel.setForeground(Color.white);
        loginPanel.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(125, 270, 200, 30);
        passwordField.setFont(new Font("Arial", Font.BOLD, 16));
        passwordField.setForeground(Color.black);
        passwordField.setBackground(new Color(200, 200, 200));
        passwordField.setHorizontalAlignment(JTextField.CENTER);
        passwordField.setEchoChar('*');
        loginPanel.add(passwordField);

        passwordCheck = new JCheckBox("Show Password");
        passwordCheck.setBounds(125, 310, 190, 20);
        passwordCheck.setForeground(Color.white);
        passwordCheck.setOpaque(false);
        passwordCheck.addActionListener(e -> {
            if (passwordCheck.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
        });
        loginPanel.add(passwordCheck);

        loginButton = new JButton("Log In");
        loginButton.setBounds(175, 350, 90, 30);
        loginButton.setBackground(new Color(0, 0, 150));
        loginButton.setForeground(Color.white);
        loginButton.setFont(new Font("Sans Serif", Font.BOLD, 16));
        loginButton.addActionListener(this);
        loginButton.setOpaque(false);
        loginPanel.add(loginButton);

        dashboardPanel = new JPanel();
        dashboardPanel.setBounds(425, 125, 420, 400);
        dashboardPanel.setBackground(new Color(0, 0, 139));
        dashboardPanel.setLayout(null);
        dashboardPanel.setOpaque(true);

        dashboardLabel = new JLabel("DASHBOARD");
        dashboardLabel.setBounds(115, 80, 200, 40);
        dashboardLabel.setFont(new Font("Sans Serif", Font.BOLD, 30));
        dashboardLabel.setForeground(Color.white);
        dashboardPanel.add(dashboardLabel);

        depositButton = new JButton("Deposit");
        depositButton.setBounds(123, 140, 180, 40);
        depositButton.setFont(new Font("Arial", Font.BOLD, 20));
        depositButton.setForeground(new Color(0, 0, 124));
        depositButton.setBackground(Color.white);
        dashboardPanel.add(depositButton);
        depositButton.addActionListener(this);

        withdrawButton = new JButton("Withdraw");
        withdrawButton.setBounds(123, 190, 180, 40);
        withdrawButton.setFont(new Font("Arial", Font.BOLD, 20));
        withdrawButton.setForeground(new Color(0, 0, 124));
        withdrawButton.setBackground(Color.white);
        dashboardPanel.add(withdrawButton);
        withdrawButton.addActionListener(this);

        checkBalanceButton = new JButton("Check Balance");
        checkBalanceButton.setBounds(123, 240, 180, 40);
        checkBalanceButton.setFont(new Font("Arial", Font.BOLD, 20));
        checkBalanceButton.setForeground(new Color(0, 0, 124));
        checkBalanceButton.setBackground(Color.white);
        dashboardPanel.add(checkBalanceButton);
        checkBalanceButton.addActionListener(this);

        backButton = new JButton("Back");
        backButton.setBounds(123, 290, 180, 40);
        backButton.setFont(new Font("Arial", Font.BOLD, 20));
        backButton.setForeground(new Color(0, 0, 124));
        backButton.setBackground(Color.white);
        dashboardPanel.add(backButton);
        backButton.addActionListener(this);

        depositPanel = new JPanel();
        depositPanel.setBounds(405, 105, 450, 420);
        depositPanel.setBackground(new Color(0, 0, 139));
        depositPanel.setLayout(null);
        depositPanel.setOpaque(true);

        depositLabel = new JLabel("DEPOSIT");
        depositLabel.setBounds(150, 90, 200, 40);
        depositLabel.setFont(new Font("Sans Serif", Font.BOLD, 32));
        depositLabel.setForeground(Color.white);
        depositPanel.add(depositLabel);

        depositAmountLabel = new JLabel("Type Amount To Deposit: ");
        depositAmountLabel.setBounds(110, 190, 320, 30);
        depositAmountLabel.setFont(new Font("Arial", Font.BOLD, 18));
        depositAmountLabel.setForeground(Color.white);
        depositPanel.add(depositAmountLabel);

        depositAmountTextField = new JTextField();
        depositAmountTextField.setBounds(130, 230, 185, 30);
        depositAmountTextField.setFont(new Font("Arial", Font.BOLD, 16));
        depositAmountTextField.setForeground(Color.BLACK);
        depositAmountTextField.setBackground(new Color(200, 200, 200));
        depositAmountTextField.setHorizontalAlignment(JLabel.CENTER);
        depositPanel.add(depositAmountTextField);

        depositAmountButton = new JButton("Deposit");
        depositAmountButton.setBounds(130, 290, 85, 30);
        depositAmountButton.setFont(new Font("Arial", Font.BOLD, 14));
        depositAmountButton.setBackground(Color.white);
        depositAmountButton.setForeground(new Color(0, 0, 139));
        depositPanel.add(depositAmountButton);
        depositAmountButton.addActionListener(this);

        backFromDepositButton = new JButton("Back");
        backFromDepositButton.setBounds(225, 290, 85, 30);
        backFromDepositButton.setFont(new Font("Arial", Font.BOLD, 14));
        backFromDepositButton.setBackground(Color.white);
        backFromDepositButton.setForeground(new Color(0, 0, 134));
        depositPanel.add(backFromDepositButton);
        backFromDepositButton.addActionListener(this);

        withdrawPanel = new JPanel();
        withdrawPanel.setBounds(405, 105, 450, 420);
        withdrawPanel.setBackground(new Color(0, 0, 139));
        withdrawPanel.setLayout(null);
        withdrawPanel.setOpaque(true);

        withdrawLabel = new JLabel("WITHDRAW");
        withdrawLabel.setBounds(135, 90, 200, 40);
        withdrawLabel.setFont(new Font("Sans Serif", Font.BOLD, 32));
        withdrawLabel.setForeground(Color.white);
        withdrawPanel.add(withdrawLabel);

        withdrawAmountLabel = new JLabel("Type Amount To Withdraw: ");
        withdrawAmountLabel.setBounds(105, 190, 320, 30);
        withdrawAmountLabel.setFont(new Font("Arial", Font.BOLD, 18));
        withdrawAmountLabel.setForeground(Color.white);
        withdrawPanel.add(withdrawAmountLabel);

        withdrawAmountTextField = new JTextField();
        withdrawAmountTextField.setBounds(135, 230, 185, 30);
        withdrawAmountTextField.setFont(new Font("Arial", Font.BOLD, 16));
        withdrawAmountTextField.setForeground(Color.BLACK);
        withdrawAmountTextField.setBackground(new Color(200, 200, 200));
        withdrawAmountTextField.setHorizontalAlignment(JLabel.CENTER);
        withdrawPanel.add(withdrawAmountTextField);

        withdrawAmountButton = new JButton("Withdraw");
        withdrawAmountButton.setBounds(115, 290, 100, 30);
        withdrawAmountButton.setFont(new Font("Arial", Font.BOLD, 14));
        withdrawAmountButton.setBackground(Color.white);
        withdrawAmountButton.setForeground(new Color(0, 0, 139));
        withdrawPanel.add(withdrawAmountButton);
        withdrawAmountButton.addActionListener(this);

        backFromWithdrawButton = new JButton("Back");
        backFromWithdrawButton.setBounds(240, 290, 100, 30);
        backFromWithdrawButton.setFont(new Font("Arial", Font.BOLD, 14));
        backFromWithdrawButton.setBackground(Color.white);
        backFromWithdrawButton.setForeground(new Color(0, 0, 134));
        withdrawPanel.add(backFromWithdrawButton);
        backFromWithdrawButton.addActionListener(this);

        checkBalancePanel = new JPanel();
        checkBalancePanel.setBounds(415, 125, 430, 380);
        checkBalancePanel.setBackground(new Color(0, 0, 139));
        checkBalancePanel.setLayout(null);
        checkBalancePanel.setOpaque(true);

        checkBalanceLabel = new JLabel("BALANCE");
        checkBalanceLabel.setBounds(145, 90, 200, 40);
        checkBalanceLabel.setFont(new Font("Sans Serif", Font.BOLD, 32));
        checkBalanceLabel.setForeground(Color.white);
        checkBalancePanel.add(checkBalanceLabel);

        existingBalanceLabel = new JLabel("Balance: " + Double.toString(balance) + "$");
        existingBalanceLabel.setBounds(140, 170, 300, 30);
        existingBalanceLabel.setFont(new Font("Arial", Font.BOLD, 20));
        existingBalanceLabel.setForeground(Color.white);
        checkBalancePanel.add(existingBalanceLabel);

        backFromBalanceButton = new JButton("Back");
        backFromBalanceButton.setBounds(180, 270, 90, 30);
        backFromBalanceButton.setFont(new Font("Arial", Font.BOLD, 14));
        backFromBalanceButton.setBackground(Color.white);
        backFromBalanceButton.setForeground(new Color(0, 0, 134));
        checkBalancePanel.add(backFromBalanceButton);
        backFromBalanceButton.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == loginButton) {
            String enteredUsername = usernameTextField.getText();
            String enteredPassword = new String(passwordField.getPassword());
            if ((enteredUsername.equals(usernames[0]) && enteredPassword.equals(passwords[0])) ||
                    (enteredUsername.equals(usernames[1]) && enteredPassword.equals(passwords[1])) ||
                    (enteredUsername.equals(usernames[2]) && enteredPassword.equals(passwords[2]))) {
                backgroundLabel.remove(loginPanel);
                backgroundLabel.add(dashboardPanel);
                backgroundLabel.revalidate();
                backgroundLabel.repaint();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password!");
            }
        } else if (e.getSource() == backButton) {
            backgroundLabel.remove(dashboardPanel);
            backgroundLabel.add(loginPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
            usernameTextField.setText("");
            passwordField.setText("");
        } else if (e.getSource() == depositButton) {
            backgroundLabel.remove(dashboardPanel);
            backgroundLabel.add(depositPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == withdrawButton) {
            backgroundLabel.remove(dashboardPanel);
            backgroundLabel.add(withdrawPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == checkBalanceButton) {
            backgroundLabel.remove(dashboardPanel);
            backgroundLabel.add(checkBalancePanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == backFromDepositButton) {
            backgroundLabel.remove(depositPanel);
            backgroundLabel.add(dashboardPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == backFromWithdrawButton) {
            backgroundLabel.remove(withdrawPanel);
            backgroundLabel.add(dashboardPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == backFromBalanceButton) {
            backgroundLabel.remove(checkBalancePanel);
            backgroundLabel.add(dashboardPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == depositAmountButton) {
            String depositedAmount = depositAmountTextField.getText();
            balance += Double.parseDouble(depositedAmount);
            existingBalanceLabel.setText("Balance: " + balance + "$");
            depositAmountTextField.setText("");
            JOptionPane.showMessageDialog(this, "Deposit Successful");
        } else if (e.getSource() == withdrawAmountButton) {
            String withdrawnAmount = withdrawAmountTextField.getText();
            balance -= Double.parseDouble(withdrawnAmount);
            existingBalanceLabel.setText("Balance: " + balance + "$");
            withdrawAmountTextField.setText("");
            JOptionPane.showMessageDialog(this, "Withdraw Successful");
        }

    }

    public static void main(String[] args) {
        new Login();
    }

}