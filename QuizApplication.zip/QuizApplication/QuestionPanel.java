import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.Timer;

public class QuestionPanel extends JPanel implements ActionListener {
    JLabel questionNumberLabel, questionLabel;
    String questions[][] = new String[10][5];
    String answers[][] = new String[10][2];
    static String userGivenAnswers[][] = new String[10][1];
    JRadioButton option1RadioButton, option2RadioButton, option3RadioButton, option4RadioButton;
    ButtonGroup optionButtonGroup;
    JButton nextButton, submitButton;
    int timer = 30;
    Timer countdownTimer;
    public static int questionNumberCount = 0;
    public static int score = 0;
    public Login login;

    public QuestionPanel(Login login) {
        this.login = login;
        setPreferredSize(new Dimension(650, 350));
        setOpaque(true);
        setLayout(null);
        setBackground(Color.white);

        fetchQuestionsFromDatabase();

        for (int i = 0; i < userGivenAnswers.length; i++) {
            userGivenAnswers[i] = new String[1];
            userGivenAnswers[i][0] = "";
        }

        questionNumberLabel = new JLabel();
        questionNumberLabel.setHorizontalAlignment(JLabel.CENTER);
        questionNumberLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
        questionNumberLabel.setSize(650, 40);
        questionNumberLabel.setLocation(0, 30);
        questionNumberLabel.setForeground(new Color(0, 0, 200, 220));
        add(questionNumberLabel);

        questionLabel = new JLabel();
        questionLabel.setHorizontalAlignment(JLabel.CENTER);
        questionLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        questionLabel.setSize(650, 30);
        questionLabel.setLocation(0, 100);
        questionLabel.setForeground(Color.BLACK);
        add(questionLabel);

        option1RadioButton = new JRadioButton();
        option1RadioButton.setBounds(110, 150, 430, 20);
        option1RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option1RadioButton.setForeground(Color.BLACK);
        option1RadioButton.setBackground(Color.white);
        add(option1RadioButton);

        option2RadioButton = new JRadioButton();
        option2RadioButton.setBounds(110, 180, 430, 20);
        option2RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option2RadioButton.setForeground(Color.BLACK);
        option2RadioButton.setBackground(Color.white);
        add(option2RadioButton);

        option3RadioButton = new JRadioButton();
        option3RadioButton.setBounds(110, 210, 430, 20);
        option3RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option3RadioButton.setForeground(Color.BLACK);
        option3RadioButton.setBackground(Color.white);
        add(option3RadioButton);

        option4RadioButton = new JRadioButton();
        option4RadioButton.setBounds(110, 240, 430, 20);
        option4RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option4RadioButton.setForeground(Color.BLACK);
        option4RadioButton.setBackground(Color.white);
        add(option4RadioButton);

        optionButtonGroup = new ButtonGroup();
        optionButtonGroup.add(option1RadioButton);
        optionButtonGroup.add(option2RadioButton);
        optionButtonGroup.add(option3RadioButton);
        optionButtonGroup.add(option4RadioButton);

        nextButton = new JButton("Next");
        nextButton.setBounds(210, 280, 90, 30);
        nextButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        nextButton.setForeground(new Color(0, 0, 200, 220));
        add(nextButton);
        nextButton.addActionListener(this);

        submitButton = new JButton("Submit");
        submitButton.setBounds(330, 280, 90, 30);
        submitButton.setForeground(new Color(0, 0, 200, 220));
        submitButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        submitButton.setEnabled(false);
        add(submitButton);
        submitButton.addActionListener(this);

        startTimer();
        questionNumber(questionNumberCount);
    }

    private void fetchQuestionsFromDatabase() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT question_text, option_a, option_b, option_c, option_d, correct_answer " +
                       "FROM quiz_questions ORDER BY RAND() LIMIT 10";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            int index = 0;
            while (resultSet.next() && index < questions.length) {
                questions[index][0] = resultSet.getString("question_text");
                questions[index][1] = resultSet.getString("option_a");
                questions[index][2] = resultSet.getString("option_b");
                questions[index][3] = resultSet.getString("option_c");
                questions[index][4] = resultSet.getString("option_d");
                answers[index][1] = resultSet.getString("correct_answer");
                index++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void questionNumber(int questionNumber) {
        if (questionNumber < questions.length) {
            questionNumberLabel.setText("Question " + (questionNumber + 1));
            questionLabel.setText(questions[questionNumber][0]);
            option1RadioButton.setText(questions[questionNumber][1]);
            option1RadioButton.setActionCommand(questions[questionNumber][1]);
            option2RadioButton.setText(questionNumber < questions.length ? questions[questionNumber][2] : ""); // Handle
                                                                                                               // potential
                                                                                                               // null
                                                                                                               // pointer
            option2RadioButton.setActionCommand(questionNumber < questions.length ? questions[questionNumber][2] : ""); // Handle
                                                                                                                        // potential
                                                                                                                        // null
                                                                                                                        // pointer
            option3RadioButton.setText(questionNumber < questions.length ? questions[questionNumber][3] : ""); // Handle
                                                                                                               // potential
                                                                                                               // null
                                                                                                               // pointer
            option3RadioButton.setActionCommand(questionNumber < questions.length ? questions[questionNumber][3] : ""); // Handle
                                                                                                                        // potential
                                                                                                                        // null
                                                                                                                        // pointer
            option4RadioButton.setText(questionNumber < questions.length ? questions[questionNumber][4] : ""); // Handle
                                                                                                               // potential
                                                                                                               // null
                                                                                                               // pointer
            option4RadioButton.setActionCommand(questionNumber < questions.length ? questions[questionNumber][4] : ""); // Handle
                                                                                                                        // potential
                                                                                                                        // null
                                                                                                                        // pointer
            optionButtonGroup.clearSelection();
            timer = 30;
            startTimer();
        }
    }

    private void startTimer() {
        if (countdownTimer != null) {
            countdownTimer.stop();
        }
        countdownTimer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (timer > 0) {
                    timer--;
                    repaint();
                } else {
                    handleTimeUp();
                }
            }
        });
        countdownTimer.start();
    }

    public void paint(Graphics graphics) {
        super.paint(graphics);
        String time = "Remaining Time: " + timer + " seconds";
        graphics.drawString(time, 440, 300);
    }

    private void handleTimeUp() {
        recordAnswer();
        if (questionNumberCount == questions.length - 1) {
            nextButton.setEnabled(false);
            submitButton.setEnabled(true);
            calculateScore();
            login.showScore(score);
        } else {
            questionNumberCount++;
            questionNumber(questionNumberCount);
        }
    }

    private void recordAnswer() {
        if (optionButtonGroup.getSelection() != null) {
            String selected = optionButtonGroup.getSelection().getActionCommand();
            userGivenAnswers[questionNumberCount][0] = selected;
            String correct = answers[questionNumberCount][1];
            if (!selected.equals(correct)) {
                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Wrong answer!\nCorrect answer: " + correct,
                        "Answer Check",
                        javax.swing.JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void calculateScore() {
        for (int i = 0; i < userGivenAnswers.length; i++) {
            if (userGivenAnswers[i][0] != null && userGivenAnswers[i][0].equals(answers[i][1])) {
                score += 10;
            }
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nextButton) {
            recordAnswer();
            if (questionNumberCount < questions.length - 1) {
                questionNumberCount++;
                questionNumber(questionNumberCount);
            } else {
                nextButton.setEnabled(false);
                submitButton.setEnabled(true);
            }
        } else if (e.getSource() == submitButton) {
            recordAnswer();
            calculateScore();
            login.showScore(score);
        }
    }

    public void setQuestion(String question) {
        questionNumberLabel.setText(question);
    }
}