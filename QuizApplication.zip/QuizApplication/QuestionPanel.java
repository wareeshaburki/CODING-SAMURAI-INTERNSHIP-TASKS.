import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.Timer;

public class QuestionPanel extends JPanel implements ActionListener {
    JLabel questionNumberLabel, questionLabel;
    String questions[][] = new String[10][5];
    String answers[][] = new String[10][2];
    String userGivenAnswers[][] = new String[10][1];
    JRadioButton option1RadioButton, option2RadioButton, option3RadioButton, option4RadioButton;
    ButtonGroup optionButtonGroup;
    JButton nextButton, submitButton;
    int timer = 30;
    Timer countdownTimer;
    public static int questionNumberCount = 0;
    public static int score = 0;
    public Login login;

    public QuestionPanel(Login login) {
        this.login = login;
        setPreferredSize(new Dimension(650, 350));
        setOpaque(true);
        setLayout(null);
        setBackground(Color.white);

        for (int i = 0; i < userGivenAnswers.length; i++) {
            userGivenAnswers[i] = new String[1];
            userGivenAnswers[i][0] = "";
        }

        questionNumberLabel = new JLabel();
        questionNumberLabel.setHorizontalAlignment(JLabel.CENTER);
        questionNumberLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
        questionNumberLabel.setSize(650, 40);
        questionNumberLabel.setLocation(0, 30);
        questionNumberLabel.setForeground(new Color(0, 0, 200, 220));
        add(questionNumberLabel);

        questionLabel = new JLabel();
        questionLabel.setHorizontalAlignment(JLabel.CENTER);
        questionLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        questionLabel.setSize(650, 30);
        questionLabel.setLocation(0, 100);
        questionLabel.setForeground(Color.BLACK);
        add(questionLabel);

        initializeQuestions();

        option1RadioButton = new JRadioButton();
        option1RadioButton.setBounds(110, 150, 430, 20);
        option1RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option1RadioButton.setForeground(Color.BLACK);
        option1RadioButton.setBackground(Color.white);
        add(option1RadioButton);

        option2RadioButton = new JRadioButton();
        option2RadioButton.setBounds(110, 180, 430, 20);
        option2RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option2RadioButton.setForeground(Color.BLACK);
        option2RadioButton.setBackground(Color.white);
        add(option2RadioButton);

        option3RadioButton = new JRadioButton();
        option3RadioButton.setBounds(110, 210, 430, 20);
        option3RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option3RadioButton.setForeground(Color.BLACK);
        option3RadioButton.setBackground(Color.white);
        add(option3RadioButton);

        option4RadioButton = new JRadioButton();
        option4RadioButton.setBounds(110, 240, 430, 20);
        option4RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        option4RadioButton.setForeground(Color.BLACK);
        option4RadioButton.setBackground(Color.white);
        add(option4RadioButton);

        optionButtonGroup = new ButtonGroup();
        optionButtonGroup.add(option1RadioButton);
        optionButtonGroup.add(option2RadioButton);
        optionButtonGroup.add(option3RadioButton);
        optionButtonGroup.add(option4RadioButton);

        nextButton = new JButton("Next");
        nextButton.setBounds(210, 280, 90, 30);
        nextButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        nextButton.setForeground(new Color(0, 0, 200, 220));
        add(nextButton);
        nextButton.addActionListener(this);

        submitButton = new JButton("Submit");
        submitButton.setBounds(330, 280, 90, 30);
        submitButton.setForeground(new Color(0, 0, 200, 220));
        submitButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        submitButton.setEnabled(false);
        add(submitButton);
        submitButton.addActionListener(this);

        startTimer();
        questionNumber(questionNumberCount);
    }

    private void initializeQuestions() {
        questions[0][0] = "Which of the following is used to implement multithreading in Java?";
        questions[0][1] = "Thread class";
        questions[0][2] = "Runnable interface";
        questions[0][3] = "Executor framework";
        questions[0][4] = "All of the above";

        questions[1][0] = "What does the 'final' keyword in Java signify?";
        questions[1][1] = "Constant variable";
        questions[1][2] = "Final method cannot be overridden";
        questions[1][3] = "Final class cannot be inherited";
        questions[1][4] = "All of the above";

        questions[2][0] = "What is the default value of a boolean variable in Java?";
        questions[2][1] = "true";
        questions[2][2] = "false";
        questions[2][3] = "0";
        questions[2][4] = "null";

        questions[3][0] = "Which of the following is the root class of all exceptions in Java?";
        questions[3][1] = "Throwable";
        questions[3][2] = "Exception";
        questions[3][3] = "Error";
        questions[3][4] = "RuntimeException";

        questions[4][0] = "What is the purpose of the 'transient' keyword in Java?";
        questions[4][1] = "To prevent serialization";
        questions[4][2] = "To make a variable constant";
        questions[4][3] = "To make a class abstract";
        questions[4][4] = "To declare a method final";

        questions[5][0] = "Which of the following can be used to create a thread in Java?";
        questions[5][1] = "Extending the Thread class";
        questions[5][2] = "Implementing the Runnable interface";
        questions[5][3] = "Using the Executor framework";
        questions[5][4] = "All of the above";

        questions[6][0] = "Which collection class maintains the order of elements in Java?";
        questions[6][1] = "HashSet";
        questions[6][2] = "ArrayList";
        questions[6][3] = "HashMap";
        questions[6][4] = "TreeSet";

        questions[7][0] = "What is the output of the following code: int a = 5; System.out.println(a++ + ++a);?";
        questions[7][1] = "11";
        questions[7][2] = "12";
        questions[7][3] = "10";
        questions[7][4] = "Error";

        questions[8][0] = "Which of the following is not a primitive data type in Java?";
        questions[8][1] = "int";
        questions[8][2] = "boolean";
        questions[8][3] = "String";
        questions[8][4] = "float";

        questions[9][0] = "What is the use of the 'synchronized' keyword in Java?";
        questions[9][1] = "To restrict access to a method or block";
        questions[9][2] = "To implement polymorphism";
        questions[9][3] = "To define a constant value";
        questions[9][4] = "To handle exceptions";

        answers[0][1] = "All of the above";
        answers[1][1] = "All of the above";
        answers[2][1] = "false";
        answers[3][1] = "Throwable";
        answers[4][1] = "To prevent serialization";
        answers[5][1] = "All of the above";
        answers[6][1] = "ArrayList";
        answers[7][1] = "12";
        answers[8][1] = "String";
        answers[9][1] = "To restrict access to a method or block";
    }

    public void questionNumber(int questionNumber) {
        if (questionNumber < questions.length) {
            questionNumberLabel.setText("Question " + (questionNumber + 1));
            questionLabel.setText(questions[questionNumber][0]);
            option1RadioButton.setText(questions[questionNumber][1]);
            option1RadioButton.setActionCommand(questions[questionNumber][1]);
            option2RadioButton.setText(questionNumber < questions.length ? questions[questionNumber][2] : ""); // Handle
                                                                                                               // potential
                                                                                                               // null
                                                                                                               // pointer
            option2RadioButton.setActionCommand(questionNumber < questions.length ? questions[questionNumber][2] : ""); // Handle
                                                                                                                        // potential
                                                                                                                        // null
                                                                                                                        // pointer
            option3RadioButton.setText(questionNumber < questions.length ? questions[questionNumber][3] : ""); // Handle
                                                                                                               // potential
                                                                                                               // null
                                                                                                               // pointer
            option3RadioButton.setActionCommand(questionNumber < questions.length ? questions[questionNumber][3] : ""); // Handle
                                                                                                                        // potential
                                                                                                                        // null
                                                                                                                        // pointer
            option4RadioButton.setText(questionNumber < questions.length ? questions[questionNumber][4] : ""); // Handle
                                                                                                               // potential
                                                                                                               // null
                                                                                                               // pointer
            option4RadioButton.setActionCommand(questionNumber < questions.length ? questions[questionNumber][4] : ""); // Handle
                                                                                                                        // potential
                                                                                                                        // null
                                                                                                                        // pointer
            optionButtonGroup.clearSelection();
            timer = 30;
            startTimer();
        }
    }

    private void startTimer() {
        if (countdownTimer != null) {
            countdownTimer.stop();
        }
        countdownTimer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (timer > 0) {
                    timer--;
                    repaint();
                } else {
                    handleTimeUp();
                }
            }
        });
        countdownTimer.start();
    }

    public void paint(Graphics graphics) {
        super.paint(graphics);
        String time = "Remaining Time: " + timer + " seconds";
        graphics.drawString(time, 440, 300);
    }

    private void handleTimeUp() {
        recordAnswer();
        if (questionNumberCount == questions.length - 1) {
            nextButton.setEnabled(false);
            submitButton.setEnabled(true);
            calculateScore();
            login.showScore(score);
        } else {
            questionNumberCount++;
            questionNumber(questionNumberCount);
        }
    }

    private void recordAnswer() {
        if (optionButtonGroup.getSelection() != null) {
            String selected = optionButtonGroup.getSelection().getActionCommand();
            userGivenAnswers[questionNumberCount][0] = selected;
            String correct = answers[questionNumberCount][1];
            if (!selected.equals(correct)) {
                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Wrong answer!\nCorrect answer: " + correct,
                        "Answer Check",
                        javax.swing.JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void calculateScore() {
        for (int i = 0; i < userGivenAnswers.length; i++) {
            if (userGivenAnswers[i][0] != null && userGivenAnswers[i][0].equals(answers[i][1])) {
                score += 10;
            }
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nextButton) {
            recordAnswer();
            if (questionNumberCount < questions.length - 1) {
                questionNumberCount++;
                questionNumber(questionNumberCount);
            } else {
                nextButton.setEnabled(false);
                submitButton.setEnabled(true);
            }
        } else if (e.getSource() == submitButton) {
            recordAnswer();
            calculateScore();
            login.showScore(score);
        }
    }

    public void setQuestion(String question) {
        questionNumberLabel.setText(question);
    }
}