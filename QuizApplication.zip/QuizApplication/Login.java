import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class Login extends JFrame implements ActionListener {

    public JLabel backgroundLabel, headingLabel, nameLabel, rulesHeadingLabel, rulesLabel, questionNumberLabel;
    public JPanel loginPanel, rulesPanel, questionsPanel;
    public JTextField nameField;
    JButton rulesButton, exitButton, backButton, startButton;
    public QuestionPanel questionPanel;
    Border border = BorderFactory.createLineBorder(Color.gray, 2);
    public GridBagConstraints gridBagConstraints;

    Login() {
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon backgroundImage = new ImageIcon("loginimg.jpg");
        Image scaledImage = backgroundImage.getImage().getScaledInstance(
                Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height,
                Image.SCALE_SMOOTH);
        backgroundLabel = new JLabel(new ImageIcon(scaledImage));
        backgroundLabel.setLayout(new GridBagLayout());
        setContentPane(backgroundLabel);
        setTitle("BrainBuzz");

        loginPanel = new JPanel();
        loginPanel.setPreferredSize(new Dimension(500, 500));
        loginPanel.setOpaque(true);
        loginPanel.setLayout(null);
        loginPanel.setBackground(new Color(0, 0, 200, 220));

        loginPanel.setBorder(border);

        headingLabel = new JLabel("BrainBuzz");
        headingLabel.setHorizontalAlignment(JLabel.CENTER);
        headingLabel.setFont(new Font("Times New Roman", Font.BOLD, 48));
        headingLabel.setSize(500, 60);
        headingLabel.setLocation(0, 100);
        headingLabel.setForeground(Color.WHITE);
        loginPanel.add(headingLabel);

        nameLabel = new JLabel("Enter your name: ");
        nameLabel.setHorizontalAlignment(JLabel.CENTER);
        nameLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        nameLabel.setSize(500, 40);
        nameLabel.setLocation(0, 200);
        nameLabel.setForeground(Color.WHITE);
        loginPanel.add(nameLabel);

        nameField = new JTextField(30);
        nameField.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        nameField.setSize(250, 30);
        nameField.setLocation(130, 250);
        loginPanel.add(nameField);

        rulesButton = new JButton("Rules");
        rulesButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
        rulesButton.setSize(100, 40);
        rulesButton.setLocation(140, 320);
        rulesButton.setForeground(new Color(0, 0, 150));
        loginPanel.add(rulesButton);
        rulesButton.addActionListener(this);

        exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
        exitButton.setSize(100, 40);
        exitButton.setLocation(265, 320);
        exitButton.setForeground(new Color(0, 0, 150));
        loginPanel.add(exitButton);
        exitButton.addActionListener(this);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        backgroundLabel.add(loginPanel, gridBagConstraints);

        rulesPanel = new JPanel();
        rulesPanel.setPreferredSize(new Dimension(650, 400));
        rulesPanel.setOpaque(true);
        rulesPanel.setLayout(null);
        rulesPanel.setBackground(Color.white);
        rulesPanel.setBorder(border);

        rulesHeadingLabel = new JLabel("Quiz Rules");
        rulesHeadingLabel.setHorizontalAlignment(JLabel.CENTER);
        rulesHeadingLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        rulesHeadingLabel.setSize(650, 60);
        rulesHeadingLabel.setLocation(0, 60);
        rulesHeadingLabel.setForeground(new Color(0, 0, 200, 220));
        rulesPanel.add(rulesHeadingLabel);

        rulesLabel = new JLabel("<html>"
                + "1. Participants must be at least 16 years old.<br>"
                + "2. The quiz consists of 10 multiple-choice questions with 4 options each.<br>"
                + "3. Participants have 5 minutes to complete the quiz (each mcq having 30 seconds).<br>"
                + "4. Correct answers earn points; no penalties for incorrect answers.<br>"
                + "5. Participants must complete the quiz independently.<br>"
                + "6. Results will be available after the quiz ends."
                + "</html>");
        rulesLabel.setHorizontalAlignment(JLabel.CENTER);
        rulesLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        rulesLabel.setSize(650, 200);
        rulesLabel.setLocation(0, 110);
        rulesLabel.setForeground(Color.BLACK);
        rulesPanel.add(rulesLabel);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
        backButton.setSize(100, 40);
        backButton.setLocation(200, 320);
        backButton.setForeground(new Color(0, 0, 150));
        rulesPanel.add(backButton);
        backButton.addActionListener(this);

        startButton = new JButton("Start");
        startButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
        startButton.setSize(100, 40);
        startButton.setLocation(320, 320);
        startButton.setForeground(new Color(0, 0, 150));
        rulesPanel.add(startButton);
        startButton.addActionListener(this);

        questionPanel = new QuestionPanel(this);
        questionPanel.setBorder(border);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == rulesButton) {
            backgroundLabel.remove(loginPanel);
            backgroundLabel.add(rulesPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == exitButton) {
            setVisible(false);
        } else if (e.getSource() == backButton) {
            backgroundLabel.remove(rulesPanel);
            backgroundLabel.add(loginPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        } else if (e.getSource() == startButton) {
            backgroundLabel.remove(rulesPanel);
            backgroundLabel.add(questionPanel);
            backgroundLabel.revalidate();
            backgroundLabel.repaint();
        }
    }

    public void showScore(int score) {
        String name = nameField.getText();
        Score scorePanel = new Score(this, name, score); 
        scorePanel.setBorder(border);
        backgroundLabel.remove(questionPanel);
        backgroundLabel.add(scorePanel);
        backgroundLabel.revalidate();
        backgroundLabel.repaint();
    }

    public void showLoginPanel() {
        backgroundLabel.removeAll();
        backgroundLabel.add(loginPanel, gridBagConstraints);
        backgroundLabel.revalidate();
        backgroundLabel.repaint();
    }

    public static void main(String[] args) {
        new Login();
    }
}