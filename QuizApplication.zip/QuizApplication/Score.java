import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Score extends JPanel implements ActionListener{
    JLabel scoreLabel;
    public JButton restartButton;
    private Login login;

    public Score(Login login,String name, int score) {
        this.login = login;
        setPreferredSize(new Dimension(650, 350));
        setBackground(Color.white);
        setLayout(null);
        scoreLabel = new JLabel(name + " your Score: " + score + " out of 100", JLabel.CENTER);
        scoreLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
        scoreLabel.setForeground(Color.BLACK);
        scoreLabel.setBounds(0,150,650,50);
        add(scoreLabel);

        restartButton = new JButton("Restart");
        restartButton.setBackground(new Color(0,0,210));
        restartButton.setForeground(Color.white);
        restartButton.setFont(new Font("Times New Roman",Font.BOLD,16));
        restartButton.setSize(100,40);
        restartButton.setLocation(300,300);
        add(restartButton);
        restartButton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == restartButton) {
            QuestionPanel.questionNumberCount = 0;
            QuestionPanel.score = 0;
            for (int i = 0; i < QuestionPanel.userGivenAnswers.length; i++) {
                QuestionPanel.userGivenAnswers[i][0] = "";
            }
            login.showLoginPanel();
        }
    }
}